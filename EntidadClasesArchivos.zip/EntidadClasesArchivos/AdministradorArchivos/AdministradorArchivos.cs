﻿using System;
using System.IO;

namespace EndtidadesClaseArchivos
{
    public static class AdministradorArchivos
    {
        public static bool Escribir(string path, string cadena)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(path, false))
                {
                    sw.WriteLine(cadena);
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool Leer(string path, out string cadena)
        {
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    cadena = sr.ReadToEnd();
                    return true;
                }
            }
            catch (Exception ex)
            {
                cadena = "No se pudo leer en archivo";
                Console.WriteLine(ex.Message);
                return false;
            }
        }
    }
}
