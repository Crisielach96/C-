﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EndtidadesClaseArchivos;

namespace PruebaArchivo
{
    class Program
    {
        static void Main(string[] args)
        {
            string pathD;
            string pathMD;
            string pathMP;
            string carpeta;

            pathD =Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            pathMD = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            pathMP = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

            carpeta=AppDomain.CurrentDomain.BaseDirectory;

            if (AdministradorArchivos.Escribir(pathD+"test.txt", "hola escritorio"))
            {
                Console.WriteLine("Se escribio");
            }
            else
            {
                Console.WriteLine("No se pudo");
            }

            if (AdministradorArchivos.Escribir(pathMD+"test.txt", "hola documentos"))
            {
                Console.WriteLine("Se escribio");
            }
            else
            {
                Console.WriteLine("No se pudo");
            }

            if (AdministradorArchivos.Escribir(pathMP+"test.txt", "hola imagenes"))
            {
                Console.WriteLine("Se escribio");
            }
            else
            {
                Console.WriteLine("No se pudo");
            }

            if (AdministradorArchivos.Leer(carpeta + "test.txt", out string mensaje))
            {
                Console.WriteLine(mensaje);
            }
            else
            {
                Console.WriteLine("No se pudo");
            }

            Console.ReadKey();
        }
    }
}
