﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase;

namespace EjerClase04
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime fecha = new DateTime(1996,12,30);
            
            string todo0,todo1,todo2,todo3;

            Cosa clase0 = new Cosa();
            Cosa clase1 = new Cosa(21,"cris",fecha);
            Cosa clase2 = new Cosa(20);
            Cosa clase3 = new Cosa(19,"Fede");
            
            todo0 = clase0.mostrar();
            todo1 = clase1.mostrar();
            todo2 = clase2.mostrar();
            todo3 = clase3.mostrar();

            Console.Write(todo0);
            Console.Write("\n" + todo1);
            Console.Write("\n" + todo2);
            Console.Write("\n" + todo3);

            Console.ReadKey();
        }
    }
}
