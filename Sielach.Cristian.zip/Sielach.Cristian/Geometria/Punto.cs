﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    public class Punto
    {
        private static int x;
        private static int y;

        public int GetX()
        {
            return Punto.x;
        }

        public int GetY()
        {
            return Punto.y;
        }
    }
}
