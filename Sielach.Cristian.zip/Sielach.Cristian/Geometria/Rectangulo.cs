﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    class Rectangulo
    {
        private float area;
        private float perimetro;
        private Punto vertcie1;
        private Punto vertcie2;
        private Punto vertcie3;
        private Punto vertcie4;

        public float Area()
        {
            float total = 0;


            return total;
        }

        public float Perimetro()
        {
            float total02 = 0;

            return total02;
        }

        public void Rectangulo(Punto vertice1, Punto vertice3)
        {
            Math.Abs();
        }
    }
}
