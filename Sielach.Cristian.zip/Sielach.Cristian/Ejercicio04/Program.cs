﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio04
{
    class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;

            for (int i = 8128; i > 1; i--)
            {
                suma = 0;

                for (int j = 1; j < i; j++)
                {
                    if (i % j == 0 && i != j)
                    {
                        suma = suma + j;
                    }
                }
                if (suma == i)
                {
                    Console.WriteLine("{0}", i);
                }
            }
            Console.ReadKey();
        }
    }
}
