﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase
{
    public class Cosa
    {
        public int entero;
        public string cadena;
        public DateTime fecha;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="valor"></param>
        public void EstablecerValor(int valor)
        {
            this.entero = valor;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valor"></param>
        public void EstablecerValor(string valor)
        {
            this.cadena = valor;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valor"></param>
        public void EstablecerValor(DateTime valor)
        {
            this.fecha=valor;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string mostrar()
        {
            string total;

            total= this.entero+ "\n" + this.cadena + "\n" + this.fecha +"\n";

            return total;
        }


        /// <summary>
        /// 
        /// </summary>
        public Cosa()
        {
            entero = 15;
            cadena = "Hola";
            fecha = DateTime.Now;
        }
        public Cosa(int entero, string cadena, DateTime fecha)
        {
            this.entero = entero;
            this.cadena = cadena;
            this.fecha = fecha; 
        }
        public Cosa(int entero,string cadena):this(entero)
        {
            this.cadena = cadena;
        }
        public Cosa(int entero):this()
        {
            this.entero = entero;
        }
    }
}
