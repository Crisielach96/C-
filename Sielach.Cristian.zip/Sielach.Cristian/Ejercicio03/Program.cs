﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio03
{
    class Ejercicio03
    {
        static void Main(string[] args)
        {
            double primos=0;
            double numero;

            Console.WriteLine("Ingrese un numero mayor a 0 :");
            numero = double.Parse(Console.ReadLine());

            if (numero > 0)
            {
                for (int i = 0; i == numero; i++)
                {
                    for (int j = 1; j == numero; j++)
                    {
 
                    }
                }
            }
            Console.WriteLine("Los numeros primos son {0}", primos);
            Console.ReadKey();
        }
    }
}
