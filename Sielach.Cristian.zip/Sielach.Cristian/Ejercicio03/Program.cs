﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio03
{
    class Ejercicio03
    {
        static void Main(string[] args)
        {
            double numero;
            int flag = 0;

            Console.WriteLine("Ingrese un numero mayor a 0 :");
            numero = double.Parse(Console.ReadLine());

            if (numero > 0)
            {
                
                for (double i = numero; i > 1; i--)
                {
                    flag = 0;
                    for (int j = 2; j < i; j++)
                    {
                        if (i % j == 0)
                        {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 0)
                    {
                        Console.WriteLine("{0}", i);
                    }
                }
            }
            else
            {
                Console.WriteLine("Error");
            }
            Console.ReadKey();
        }
    }
}
