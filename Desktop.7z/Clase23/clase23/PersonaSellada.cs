﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Alumnos;
using Entidades.Externa;

namespace clase23
{
    public class PersonaSellada : Persona
    {
        public PersonaSellada(string nombre, string apellido, int edad, ESexo sexo)
            : base(nombre, apellido, edad, sexo){ }

        public string Nombre { get { return this._nombre; } }
        public string Apellido { get { return this._apellido; } }
        public int Edad { get { return this._edad; } }
        public ESexo Sexo { get { return this._sexo; } }
    }
}
