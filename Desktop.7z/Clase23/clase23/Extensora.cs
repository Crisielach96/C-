﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Alumnos;
using Entidades.Externa;
using System.IO;
using System.Data.SqlClient;
using System.Data;


namespace clase23
{
    
    //private const string FILE_NAME = "C:\\TestFile.txt";

    static public class Extensora
    {

        public static string ObtenerInfo(this Persona p)
        {
             return string.Format("{0} {1} {2} {3}",p.Nombre,p.Apellido,p.Edad,p.Sexo);
        }

        public static string ObtenerInfo(this PersonaSellada p)
        {
            return string.Format("{0} {1} {2} {3}", p.Nombre, p.Apellido, p.Edad, p.Sexo);
        }
        //public void archivo()
        //{
        //try
        //    {
        //        using (StreamWriter sw = new StreamWriter(@"C:\TestFile.txt"))
        //        {
        //            // Agrega algún texto al archivo.

        //            sw.Write("Este es el ");
        //            sw.WriteLine("Encabezado para el archivo.");
        //            sw.WriteLine("-----------------------------");

        //            // Objetos arbitrarios tambien pueden ser escritos en el archivo.

        //            sw.Write("LA FECHA ES: ");
        //            sw.WriteLine(DateTime.Now);
        //        }

        //        Console.WriteLine("El archivo fue escrito exitosamente.....");
        //        Console.ReadLine();

        //        // Crea una instancia de StreamReader para leer desde el archivo.
        //        using (StreamReader sr = new StreamReader(FILE_NAME))
        //        {
        //            String line;

        //            // Lee y muestra líneas desde el comienzo del archivo 
        //            // hasta el fin del mismo.

        //            while ((line = sr.ReadLine()) != null)
        //            {
        //                Console.WriteLine(line);
        //            }
        //            Console.WriteLine();
        //            Console.WriteLine("Datos recuperados desde el archivo.....");
        //            Console.ReadLine();
        //        }
        //    }
        //    catch (Exception e)
        //    {

        //        Console.WriteLine("Error en el archivo ubicado en {0}", FILE_NAME);
        //        Console.WriteLine(e.Message);
        //        Console.ReadLine();
        //    }
        //    finally
        //    {
        //        Console.WriteLine("Pulse cualquier tecla para salir...");
        //        Console.ReadLine();
        //    }
        //}


        public static bool ConectarDB(this Persona p)
        {
            bool returnValue = true;

            try
            {
            SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.Setting);
            SqlCommand sqlCommand = new SqlCommand("insert into Personas (nombre,apellido,edad,sexo) values ('" + p.Nombre + "','" +
                         p.Apellido + "','" + p.Edad + "'," + ((int)p.Sexo) + ")"
                           , sqlConnection);

            sqlConnection.Open();

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();
            }

            catch (Exception)
            {
                returnValue = false;
            }          

            return returnValue;
        }

        public static List<Persona> TraerTodos()
        {
            List<Persona> per = new List<Persona>();
            //el namespace properties se crea cuando guardo la value en setting//
            
            SqlConnection baseDeDato = new SqlConnection(Properties.Settings.Default.Setting);
            //abre la conexion//
            
            baseDeDato.Open();
            //configo para poder pasarle comandos a la base de datos//
            
            SqlCommand comando = new SqlCommand("SELECT [id],[apellido],[nombre],[sexo],[edad] FROM [PersonasDB].[dbo].[Personas]", baseDeDato);
            //el sqldatareader no se puede instanciar , siempre le pasa el valor el execute reader//
            //es un objeto de solo lectura y de avance , es decir cada vez que lee algo lo elimina y pasa al siguiente//
            
            SqlDataReader lectura = comando.ExecuteReader();

            ESexo sexo;
            while (lectura.Read())
            {
                if ((int)(lectura["sexo"]) == 1)
                {
                    sexo = Entidades.Alumnos.ESexo.Masculino;
                }
                else
                {
                    sexo=Entidades.Alumnos.ESexo.Femenino;
                }
                // lectura[0].ToString();//me traeria solo el nombre. siempre devuelve un obj porque puede ser cualq tipo de dato//
                // lectura["id"];//otra manera de devolver un valor//
                per.Add(new Persona(lectura["nombre"].ToString(), lectura["apellido"].ToString(), int.Parse(lectura["edad"].ToString()),sexo));
            }

            lectura.Close();
            baseDeDato.Close();

            return per;
        }
    }
}
