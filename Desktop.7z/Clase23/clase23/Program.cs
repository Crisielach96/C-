﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Alumnos;
using Entidades.Externa.Sellada;

namespace clase23
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona pers0 = new Persona("Cristian", "Sielach", 21, Entidades.Alumnos.ESexo.Masculino);
            Persona pers1 = new Persona("Julian", "Rodriguez", 20, Entidades.Alumnos.ESexo.Masculino);

            Console.WriteLine(pers0.ToString());
            Console.WriteLine(pers1.ToString());

            Console.WriteLine(pers0.ObtenerInfo());

            if (pers0.ConectarDB())
            {
                Console.WriteLine("\nSe agregó correctamente\n\n");
            }
            else
            {
                Console.WriteLine("\nNo se agregó\n");
            }



            Console.ReadKey();
 
        }
    }
}
