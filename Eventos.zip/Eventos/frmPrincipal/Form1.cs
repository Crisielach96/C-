using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPrincipal
{
  public delegate void MiDelegado(Object o, EventArgs e);

  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    void MiOtroManejador(Object o, EventArgs e)
    {
      if (o.Equals(this.button1))
      {
        this.button1.Click -= new EventHandler(MiManejadorClick);
        this.button1.Click -= new EventHandler(MiOtroManejador);
        this.button2.Click += new EventHandler(MiManejadorClick);
        this.button2.Click += new EventHandler(MiOtroManejador);
      }
      else if (o.Equals(this.button2))
      {
        this.button2.Click -= new EventHandler(MiManejadorClick);
        this.button2.Click -= new EventHandler(MiOtroManejador);
        this.textBox1.Click += new EventHandler(MiManejadorClick);
        this.textBox1.Click += new EventHandler(MiOtroManejador);
      }
      else if (o.Equals(this.textBox1))
      {
        this.textBox1.Click -= new EventHandler(MiManejadorClick);
        this.textBox1.Click -= new EventHandler(MiOtroManejador);
        this.button1.Click += new EventHandler(MiManejadorClick);
        this.button1.Click += new EventHandler(MiOtroManejador);
      }
      
    }

    void MiManejadorClick(Object o, EventArgs ev)
    {
      MessageBox.Show(((Control)o).Name);
    }

    void CambiarFondo(Object o, EventArgs e)
    {
      ((Control)o).BackColor = Color.Green;
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      this.button1.Click += new EventHandler(MiManejadorClick);
      this.button1.Click += new EventHandler(MiOtroManejador);

      /*
      this.button1.Click += new EventHandler(CambiarFondo);
      this.button1.Click += new EventHandler(MiManejadorClick);
      this.button2.Click += new EventHandler(MiManejadorClick);
      this.textBox1.Click += new EventHandler(MiManejadorClick);
      this.Click += new EventHandler(MiOtroManejador);
      */
    }

    private void button3_Click(object sender, EventArgs e)
    {
      this.button1.Click -= new EventHandler(MiManejadorClick);
      this.button1.Click -= new EventHandler(CambiarFondo);
      this.button2.Click -= new EventHandler(MiManejadorClick);
      this.textBox1.Click -= new EventHandler(MiManejadorClick);
      this.Click -= new EventHandler(MiOtroManejador);
    }

    private void button1_Click(object sender, EventArgs e)
    {
      
    }

    private void button2_Click(object sender, EventArgs e)
    {
      
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {
      
    }
  }
}
