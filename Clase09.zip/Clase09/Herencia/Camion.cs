﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia
{
    public class Camion : Vehiculos
    {
        protected float _tara;

        public Camion(string patente, Byte cantRuedas, EMarca marca, float tara) : base(patente,cantRuedas,marca)
        {
            this._tara = tara;
        }

        public string MostrarCamion()
        {
            return base.Mostrar() + " - " + this._tara;
        }
    }
}
