﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia
{
    public class Moto : Vehiculos
    {
        protected float _cilindrada;

        public Moto(string patente, Byte cantRuedas, EMarca marca, float cilindrada) : base(patente,cantRuedas,marca)
        {
            this._cilindrada = cilindrada;
        }

        public string MostrarMoto()
        {
            return base.Mostrar() + " - " + this._cilindrada;
        }
    }
}
