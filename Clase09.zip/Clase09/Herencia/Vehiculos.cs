﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia
{
    public class Vehiculos
    {
        protected string _patente;
        protected Byte _cantRuedas;
        protected EMarca _marca;

        public EMarca LecturaMarc 
        {
            get
            {
                return this._marca;
            }
        }

        public string LectruraPat
        {
            get
            {
                return this._patente;
            }
        }

        protected string Mostrar()
        {
            return this._patente + " - " + this._marca + " - " + this._cantRuedas;
        }

        public Vehiculos(string patente, Byte cantRuedas, EMarca marca)
        {
            this._patente = patente;
            this._marca = marca;
            this._cantRuedas = cantRuedas;
        }

        public bool operator ==(Vehiculos v1, Vehiculos v2)
        {
            return v1._marca == v2._marca
                && v1._patente == v2._patente;
        }

        public bool operator !=(Vehiculos v1, Vehiculos v2)
        {
            return !(v1==v2);
        }



    }
}
