﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia
{
    public class Auto : Vehiculos
    {
        protected int _cantAsientos;

        public Auto(string patente, Byte cantRuedas, EMarca marca, int cantA) : base(patente,cantRuedas,marca)
        {
            this._cantAsientos = cantA;
        }

        public string MostrarAuto()
        {
            return base.Mostrar() + " - " + this._cantAsientos;
        }
    }
}
