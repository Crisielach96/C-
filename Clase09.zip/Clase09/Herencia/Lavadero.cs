﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia
{
    class Lavadero
    {
        private List<Vehiculos> _vehiculos;
        private float _precioAuto;
        private float _precioCamion;
        private float _precioMoto;

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculos>();
            this._precioAuto = 0;
            this._precioCamion = 0;
            this._precioMoto = 0;
        }

        public Lavadero(float precioCamion)
            : this()
        {
            this._precioCamion = precioCamion;
        }

        public Lavadero(float precioCamion, float precioMoto)
            : this(precioCamion)
        {
            this._precioMoto = precioMoto;
        }

        public Lavadero(float precioCamion, float precioMoto, float precioAuto)
            : this(precioCamion, precioMoto)
        {
            this._precioAuto = precioAuto;
        }

        public string LecLav
        {
            get
            {
                string resp = "Precio auto: " + this._precioAuto + "\nPrecio camion: " + this._precioCamion + "\nPrecio moto: " + this._precioMoto;

                foreach (Vehiculos v in this._vehiculos)
                {
                    if (v is Auto)
                    {
                        resp += ((Auto)v).MostrarAuto();
                    }

                    if (v is Camion)
                    {
                        resp += ((Camion)v).MostrarCamion();
                    }

                    if (v is Moto)
                    {
                        resp += ((Moto)v).MostrarMoto();
                    }
                }

                return resp;
            }
        }

        public List<Vehiculos> GetVehiculos
        {
            get
            {
                return this._vehiculos;
            }
        }

        #region TotalFacturado

        public double TotalFacturado()
        {
            return this.TotalFacturado(EVehiculo.Auto) + this.TotalFacturado(EVehiculo.Camion) + this.TotalFacturado(EVehiculo.Moto);
        }

        public double TotalFacturado(EVehiculo v)
        {
            int conA = 0, conM = 0, conC = 0;

            foreach (Vehiculos v1 in this._vehiculos)
            {
                if (v1 is Auto)
                {
                    conA++;
                }
                if (v1 is Camion)
                {
                    conC++;
                }
                if (v1 is Moto)
                {
                    conM++;
                }
            }

                double total = 0;
                
                switch (v)
                {
                    case EVehiculo.Auto:
                        total = this._precioAuto * conA;
                        break;
                    case EVehiculo.Camion:
                        total = this._precioCamion * conC;
                        break;
                    case EVehiculo.Moto:
                        total = this._precioMoto * conM;
                        break;
                    default:
                        break;
                }
           return total;
        }
        #endregion

        public static bool operator ==(Lavadero l, Vehiculos v)
        {
            bool resp = false;

            foreach (Vehiculos v1 in l._vehiculos)
            {
                if (((object)v1) != null)
                {
                    if (v == v1)
                    {
                        resp = true;
                        break;
                    }
                }
            }
            return resp;
        }

        public static bool operator !=(Lavadero l, Vehiculos v)
        {
            return !(l == v);
        }

        public static Lavadero operator +(Lavadero l, Vehiculos v)
        {
            if (l != v)
            {
                l._vehiculos.Add(v);
            }
            return l;
        }
        public static Lavadero operator -(Lavadero l, Vehiculos v)
        {
            if (l == v)
            {
                l._vehiculos.Remove(v);
            }
            return l;
        }
    }
}
