﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase07
{
    public class Equipo
    {
        private short cantidadDeJugadores;
        private List<Jugador> Jugadores;
        private string nombre;

        private Equipo() 
        {
            this.cantidadDeJugadores = 5;
            this.Jugadores = new List<Jugador>();
        }
        public Equipo(short cantidad, string nombre)
            : this()
        {
            this.cantidadDeJugadores = cantidad;
            this.nombre = nombre;
        }

        public static bool operator +(Equipo e, Jugador j)
        {
            bool resp = false;

            if (e.cantidadDeJugadores > e.Jugadores.Count)
            {
                resp = true;
                foreach (Jugador i in e.Jugadores)
                {
                    if (j == i)
                    {
                        resp = false;
                        break;
                    }   
                }
                if (resp == true)
                {
                    e.Jugadores.Add(j);
                }
            }
                return resp;
        }
    }
}
