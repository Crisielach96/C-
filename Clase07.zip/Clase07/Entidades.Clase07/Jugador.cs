﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase07
{
    public class Jugador
    {
        private long dni;
        private string nombre;
        private int partidosJugados;
        private float promedioGoles;
        private int totalGoles;


        public long Dni 
        { 
            get
            {
                return this.dni;
            }
        }
        
        public string Nombre 
        {
            get
            {
                return this.nombre;
            }
        }
        public int PartJug {
            get
            {
                return this.partidosJugados;
            }
            }
        public int Goles 
        {
            get
            {
                return this.totalGoles;
            }
        }

        public float GetPromedioGoles()
        { 
            return this.promedioGoles;
        }

        private Jugador() { }

        public Jugador(string nombre) : this()
        {
            this.nombre = nombre;
        }

        public Jugador(long dni, string nombre, int totalGoles, int totalPartidos)
            : this(nombre)
        {
            this.dni = dni;
            this.totalGoles = totalGoles;
            this.partidosJugados = totalPartidos;
        }

        public string MostrarDatos()
        {
            return this.nombre + " - " + this.dni + " - " + this.partidosJugados + " - " + this.promedioGoles + " - " + this.totalGoles;
        }

        public static bool operator ==(Jugador j1, Jugador j2)
        {
            return j1.nombre == j2.nombre && j1.dni == j2.dni;
        }
        public static bool operator !=(Jugador j1, Jugador j2)
        {
            return !(j1==j2);
        }
    }
}
