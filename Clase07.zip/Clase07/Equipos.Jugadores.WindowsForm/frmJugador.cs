﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace Equipos.Jugadores.WindowsForm
{
    public partial class frmJugador : Form
    {

        Jugador _jugador;

        public frmJugador()
        {
            InitializeComponent();
        }

        private void txtDni_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            long dni;
            string nombre;
            int partJug;
            int goles;

            dni = long.Parse(this.txtDni.Text);
            nombre = this.txtNombre.Text;
            partJug = int.Parse(this.txtPartJug.Text);
            goles = int.Parse(this.txtGoles.Text);


            Jugador jugador = new Jugador(dni,nombre,goles,partJug);

            string mensaje = jugador.MostrarDatos();

            MessageBox.Show(mensaje);


        }
    }
}
