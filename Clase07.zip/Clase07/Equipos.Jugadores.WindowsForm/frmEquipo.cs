﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace Equipos.Jugadores.WindowsForm
{
    
    public partial class frmEquipo : Form
    {
        public frmEquipo()
        {
            InitializeComponent();
        }

        private void frmEquipo_Load(object sender, EventArgs e)
        {

        }

        private void btnAceptarEquip_Click(object sender, EventArgs e)
        {
            string nombre=this.txtNombEquip.Text;
            short cantJug=short.Parse(this.txtCantJug.Text);

            Equipo equipo = new Equipo(cantJug,nombre);
            
            this.btnAceptarEquip.Visible = false;
            this.txtNombEquip.Enabled = false;
            this.txtCantJug.Enabled = false;
            this.lsbJug.Visible = true;
            this.btnMas.Visible = true;
        }
    }
}
