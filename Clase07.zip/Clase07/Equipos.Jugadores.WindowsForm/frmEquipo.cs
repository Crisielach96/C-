﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace Equipos.Jugadores.WindowsForm
{
    
    public partial class frmEquipo : Form
    {
        Equipo _equipo;

        private void Agregar()
        {
            this.lsbJug.Items.Clear();

            foreach(Jugador item in this._equipo.GetJugadores())
            {
                this.lsbJug.Items.Add(item.MostrarDatos());
            }
        }

        public frmEquipo()
        {
            InitializeComponent();
        }

        private void frmEquipo_Load(object sender, EventArgs e)
        {

        }

        private void btnAceptarEquip_Click(object sender, EventArgs e)
        {
            string nombre=this.txtNombEquip.Text;
            short cantJug=short.Parse(this.txtCantJug.Text);

            this._equipo = new Equipo(cantJug,nombre);
            
            this.btnAceptarEquip.Visible = false;
            this.txtNombEquip.Enabled = false;
            this.txtCantJug.Enabled = false;
            this.lsbJug.Visible = true;
            this.btnMas.Visible = true;
        }

        private void btnMas_Click(object sender, EventArgs e)
        {
            frmJugador miForm = new frmJugador();
            miForm.ShowDialog();
            Jugador jugador;
            jugador = miForm.GetJugador();

            if (miForm.DialogResult == System.Windows.Forms.DialogResult.OK)
            {

                if (this._equipo + jugador)
                {
                    MessageBox.Show("Se agrego el jugador exitosamente");
                }
                else
                {
                    MessageBox.Show("No se agrego el jugador");
                }
            }
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {

        }
    }
}
