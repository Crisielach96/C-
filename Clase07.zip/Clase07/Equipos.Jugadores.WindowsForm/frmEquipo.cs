﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace Equipos.Jugadores.WindowsForm
{
    
    public partial class frmEquipo : Form
    {
        Equipo _equipo;

        private void Agregar()
        {
            this.lsbJug.Items.Clear();

            foreach(Jugador item in this._equipo.GetJugadores())
            {
                this.lsbJug.Items.Add(item.MostrarDatos());
            }
        }

        public frmEquipo()
        {
            InitializeComponent();
        }

        private void btnAceptarEquip_Click(object sender, EventArgs e)
        {
            string nombre=this.txtNombEquip.Text;
            short cantJug=short.Parse(this.txtCantJug.Text);

            this._equipo = new Equipo(cantJug,nombre);
            
            this.btnAceptarEquip.Visible = false;
            this.txtNombEquip.Enabled = false;
            this.txtCantJug.Enabled = false;
            this.lsbJug.Visible = true;
            this.btnMas.Visible = true;
            this.btnMenos.Visible = true;
            this.btnMod.Visible = true;
        }

        private void btnMas_Click(object sender, EventArgs e)
        {
            frmJugador miForm = new frmJugador();
            miForm.ShowDialog();
            Jugador jugador;
            jugador = miForm.GetJugador();

            if (miForm.DialogResult == System.Windows.Forms.DialogResult.OK)
            {

                if (this._equipo + jugador)
                {
                    MessageBox.Show("Se agrego el jugador exitosamente");
                    this.Agregar();
                }
                else
                {
                    MessageBox.Show("No se agrego el jugador");
                }
            }
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            int index = this.lsbJug.SelectedIndex;

            if (index > -1)
            {
                DialogResult resultado= MessageBox.Show(this._equipo.GetJugadores()[index].MostrarDatos(),"Esta seguro que desea eliminar a",MessageBoxButtons.OKCancel,MessageBoxIcon.Information,MessageBoxDefaultButton.Button2);
                if(resultado== System.Windows.Forms.DialogResult.OK)
                {
                    if(this._equipo - this._equipo.GetJugadores()[index])
                    {
                        MessageBox.Show("Se elimino correctamente a el jugador");
                        this.Agregar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar al jugador");
                    }
                }
            }
        }
    }
}
