﻿namespace Equipos.Jugadores.WindowsForm
{
    partial class frmEquipo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelarEquip = new System.Windows.Forms.Button();
            this.btnAceptarEquip = new System.Windows.Forms.Button();
            this.txtCantJug = new System.Windows.Forms.TextBox();
            this.txtNombEquip = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lsbJug = new System.Windows.Forms.ListBox();
            this.btnMas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCancelarEquip
            // 
            this.btnCancelarEquip.Location = new System.Drawing.Point(161, 64);
            this.btnCancelarEquip.Name = "btnCancelarEquip";
            this.btnCancelarEquip.Size = new System.Drawing.Size(75, 23);
            this.btnCancelarEquip.TabIndex = 1;
            this.btnCancelarEquip.Text = "Cancelar";
            this.btnCancelarEquip.UseVisualStyleBackColor = true;
            // 
            // btnAceptarEquip
            // 
            this.btnAceptarEquip.Location = new System.Drawing.Point(62, 64);
            this.btnAceptarEquip.Name = "btnAceptarEquip";
            this.btnAceptarEquip.Size = new System.Drawing.Size(75, 23);
            this.btnAceptarEquip.TabIndex = 2;
            this.btnAceptarEquip.Text = "Aceptar";
            this.btnAceptarEquip.UseVisualStyleBackColor = true;
            this.btnAceptarEquip.Click += new System.EventHandler(this.btnAceptarEquip_Click);
            // 
            // txtCantJug
            // 
            this.txtCantJug.Location = new System.Drawing.Point(62, 38);
            this.txtCantJug.Name = "txtCantJug";
            this.txtCantJug.Size = new System.Drawing.Size(174, 20);
            this.txtCantJug.TabIndex = 3;
            // 
            // txtNombEquip
            // 
            this.txtNombEquip.Location = new System.Drawing.Point(62, 12);
            this.txtNombEquip.Name = "txtNombEquip";
            this.txtNombEquip.Size = new System.Drawing.Size(174, 20);
            this.txtNombEquip.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Cant.Jug.";
            // 
            // lsbJug
            // 
            this.lsbJug.FormattingEnabled = true;
            this.lsbJug.Location = new System.Drawing.Point(15, 93);
            this.lsbJug.Name = "lsbJug";
            this.lsbJug.Size = new System.Drawing.Size(221, 82);
            this.lsbJug.TabIndex = 10;
            this.lsbJug.Visible = false;
            // 
            // btnMas
            // 
            this.btnMas.Location = new System.Drawing.Point(12, 181);
            this.btnMas.Name = "btnMas";
            this.btnMas.Size = new System.Drawing.Size(75, 23);
            this.btnMas.TabIndex = 11;
            this.btnMas.Text = "+";
            this.btnMas.UseVisualStyleBackColor = true;
            this.btnMas.Visible = false;
            // 
            // frmEquipo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 213);
            this.Controls.Add(this.btnMas);
            this.Controls.Add(this.lsbJug);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNombEquip);
            this.Controls.Add(this.txtCantJug);
            this.Controls.Add(this.btnAceptarEquip);
            this.Controls.Add(this.btnCancelarEquip);
            this.Enabled = false;
            this.Name = "frmEquipo";
            this.Text = "Equipo";
            this.Load += new System.EventHandler(this.frmEquipo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancelarEquip;
        private System.Windows.Forms.Button btnAceptarEquip;
        private System.Windows.Forms.TextBox txtCantJug;
        private System.Windows.Forms.TextBox txtNombEquip;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lsbJug;
        private System.Windows.Forms.Button btnMas;
    }
}