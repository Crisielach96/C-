﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clase07;

namespace Test01
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
