﻿using System;

namespace Clase07
{
    public class Class1
    {

    }
}
