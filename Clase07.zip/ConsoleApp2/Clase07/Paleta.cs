﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaElementos;

        #region Constructores
        private Paleta() : this(5) { }

        private Paleta(int cantMaximaElementos)
        {
            this._cantMaximaElementos = cantMaximaElementos;
            this._colores = new Tempera[this._cantMaximaElementos];
        }
        #endregion

        private string Mostrar()
        {

            string retorno = "";

            Console.WriteLine(this._cantMaximaElementos);

            foreach (Tempera item in this._colores)
            {
                retorno += item + "\n";
            }
            return retorno;
        }

        public static explicit operator string(Paleta paleta)
        {
            return paleta.Mostrar();
        }

        public static implicit operator Paleta(int num)
        {
            return new Paleta(num);
        }

        public static bool operator ==(Paleta p, Tempera t)
        {
            bool retorno = false;
            int contador = 0;

            foreach (Tempera item in p._colores)
            {
                if (p._colores.GetValue(contador) != null)
                {
                    if (t == item)
                    {
                        retorno = true;
                        break;
                    }
                }
                contador++;
            }
            return retorno;
        }

        public static bool operator !=(Paleta p, Tempera t)
        {
            return !(p == t);
        }

        private int ObtenerIndice()
        {
            int retorno=-1;
            int contador = 0;
            foreach (Tempera item in this._colores)
            {
                if (this._colores.GetValue(contador) == null)
                {
                    retorno = contador;
                    break;
                }
                contador++; 
            }
            return retorno;
        }

        private int ObtenerIndice(Tempera tempera)
        {
            int retorno = -1;
            int contador = 0;

            foreach (Tempera item in this._colores)
            {
                if (this._colores.GetValue(contador) != null)
                {
                    if (tempera == item)
                    {
                        retorno = contador;
                        break;
                    }

                }
                contador++;
            }
            return retorno;
        }

        public static Paleta operator +(Paleta paleta, Tempera tempera)
        {
            int indice = -1;

            if (paleta == tempera)
            {
                indice = paleta.ObtenerIndice(tempera);
                paleta._colores[indice] += tempera;
            }
            else
            {
                indice = paleta.ObtenerIndice();
                if(indice > -1)
                paleta._colores[indice] = tempera;
            }
            return paleta;
        }
    }
}
