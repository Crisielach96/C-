﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Entidades
{
    public static class ClaseExtensoraPersona
    {
        public static List<Persona> TraerTodos(this Persona persona)
        {
            List<Persona> listaRetorno = new List<Persona>();
            try
            {
                SqlConnection connectionSQL = new SqlConnection(Properties.Settings.Default.Conexion); 

                connectionSQL.Open(); 
                SqlCommand comandosSQL = new SqlCommand("SELECT * FROM Personas", connectionSQL); 
                SqlDataReader dataReaderSQL = comandosSQL.ExecuteReader(); 

                while (dataReaderSQL.Read()) 
                {        
                    listaRetorno.Add(new Persona(dataReaderSQL[1].ToString(), dataReaderSQL[2].ToString(), (int)dataReaderSQL[3], ((Persona.ESexo)dataReaderSQL[4]))); 
                }

                dataReaderSQL.Close(); 
                connectionSQL.Close(); 
            }
            catch (Exception e) { Console.WriteLine(e.Message); }

            return listaRetorno;
        }

        public static bool Insertar(this Persona persona)
        {
            bool retValue = false;
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();

            comando.CommandText = "Insert into Personas values ('" + persona.Nombre + "','" + persona.Apellido + "'," + persona.Edad + ",'" + (int)persona.Sexo + "' )";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                retValue = true;
            }
            catch (System.Exception)
            {

                throw;
            }


            return retValue;
        }

        public static Boolean Borrar(this Persona persona, int i)
        {
            Boolean retorno = false;
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion); //Se instancia el SqlConnection para poder utilizar la base

            try
            {
                conexion.Open(); //Se abre la conexción con la base

                SqlCommand comandosSQL = new SqlCommand("DELETE FROM Personas WHERE [id] = " + i, conexion); //Se instancia el objeto capaz de ejecutar comandos, pero se cambia la orden, siendo esta vez usada para borrar datos
                                                                                                                          /*DELETE borra todo el registro completo, sin importar el campo. De no tener con condicion WHERE, borra TODA LA BASE*/

                int registrosAfectados = comandosSQL.ExecuteNonQuery();
                //Console.WriteLine("RegistrosAfectados: {0}", registrosAfectados);

                if (registrosAfectados > 0)
                { retorno = true; }
            }
            catch (Exception e) { }
            finally { conexion.Close(); }
            return retorno;
        }

        public static bool Modificar(this Persona persona, int i)
        {
            bool retorno = false;
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);//Se instancia el SqlConnection para poder utilizar la base

            try
            {
                conexion.Open(); //Se abre la conexción con la base

                SqlCommand comandosSQL = new SqlCommand("UPDATE Personas SET [nombre] = '" + persona.Nombre + "' , [apellido] = '" + persona.Apellido + "', [edad] = " + persona.Edad + " , [sexo] = " + (int)persona.Sexo + "WHERE [id] = " + i, conexion); //Se instancia el objeto capaz de ejecutar comandos, pero se cambia la orden, siendo esta vez usada para actualizar datos
                                                                                                                                                                                                                     /*UPDATE cambia datos del registro, SET es quien hace los cambios. De nuevo, sin la condición, va a cambiar TODOS LOS REGISTROS DE LA BASE*/

                int registrosAfectados = comandosSQL.ExecuteNonQuery();
                //Console.WriteLine("RegistrosAfectados: {0}", registrosAfectados);

                if (registrosAfectados > 0) { retorno = true; }
            }
            catch (Exception e) { }
            finally { conexion.Close(); }
            return retorno;
        }

    }
}
