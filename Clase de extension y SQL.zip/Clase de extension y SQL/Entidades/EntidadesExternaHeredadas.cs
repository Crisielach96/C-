﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using Entidades.Externa;

namespace Entidades
{
    public class EntidadesExternaHeredadas : PersonaExterna
    {
        public string Nombre { get => base._nombre; }
        public string Apellido { get => base._apellido; }
        public int Edad { get => base._edad; }
        public ESexo
            Sexo { get => base._sexo; }

        public EntidadesExternaHeredadas(string nombre, string apellido, int edad, ESexo sexo) : base(nombre,apellido,edad,sexo)
        { }

        public string ObtenerDatos()
        {
            return this._nombre + " - " + this._apellido + " - " + this._edad + " - " + this._sexo;
        }
    }
}
