﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class ClaseExtensora
    {
        public static string ObtenerDatos(this Entidades.Externa.Sellada.PersonaExternaSellada dato)
        {
            return dato.Nombre + " - " + dato.Apellido + " - " + dato.Edad + " - " + dato.Sexo;
        }

        public static bool EsNulo(this Object o)
        {
            if (o != null)
            { return false; }
            else { return true; }
        }

        public static Int32 CantidadDeDigitos(this Int32 num)
        {
            string a=num.ToString();
            return a.Length;
        }

        public static bool TieneMismaCantDigitos(this Int32 num1, Int32 num2)
        {
            if(num1.CantidadDeDigitos() == num2)
            { return true; }
            else { return false; }
        }
    }
}
