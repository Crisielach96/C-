﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using Entidades.Externa;
using Entidades.Externa.Sellada;


namespace Test
{
    public class Program
    {
        static void Main(string[] args)
        {
            Persona persona1 = new Persona("Hernan","Gomez",14,Persona.ESexo.Masculino);

           // Console.WriteLine(persona1.ToString()); //Mediante metodo

           // Console.WriteLine(persona1.Nombre + " - " + persona1.Apellido + " - " + persona1.Edad + " - " + persona1.Sexo); //Mediante propiedades

            Console.WriteLine(persona1.ObtenerDatos());

            EntidadesExternaHeredadas personaExterna = new EntidadesExternaHeredadas("Jorgelina", "Lopez", 48, Entidades.Externa.ESexo.Femenino);

            Console.WriteLine(personaExterna.ObtenerDatos());

            PersonaExternaSellada personaExternaSellada = new PersonaExternaSellada("Anaclara", "Muñoz", 22, Entidades.Externa.Sellada.ESexo.Indefinido);

            Console.WriteLine(personaExternaSellada.ObtenerDatos());

            Int32 a = 3452;

            Int32 b = 2;

            Console.WriteLine(ClaseExtensora.CantidadDeDigitos(a));
            Console.WriteLine(ClaseExtensora.TieneMismaCantDigitos(a, b).ToString());

            List<Persona> personas = persona1.TraerTodos();

            foreach(Persona p in personas)
            { Console.WriteLine(p.ObtenerDatos()); }

            //persona1.Insertar();
            //persona1.Modificar(10);
            //persona1.Borrar(19);

            Console.ReadKey();
        }
    }
}
