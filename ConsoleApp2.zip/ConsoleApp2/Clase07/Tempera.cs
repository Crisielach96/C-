﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Tempera
    {
        private sbyte _cantidad;
        private ConsoleColor _color;
        private string _marca;

        public Tempera(string marca, ConsoleColor color, sbyte cantidad)
        {
            color = this._color;
            marca = this._marca;
            cantidad = this._cantidad;
        }

        private string Mostrar()
        {
            return "Marca: " + this._marca + "  Color: " + this._color + "  Cantidad: " + this._cantidad;
        }

        public static implicit operator string (Tempera tempera)
        {
            return tempera.Mostrar();
        }

        public static explicit operator sbyte(Tempera tempera)
        {
            return tempera._cantidad;
        }

        public static bool operator ==(Tempera t1, Tempera t2)
        {
            bool retorno = false;

            if (t1._color == t2._color && t1._marca == t2._marca)
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator !=(Tempera t1, Tempera t2)
        {
            return !(t1 == t2);
        }

        public static Tempera operator +(Tempera tempera, sbyte cantidad)
        {
            Tempera tempera3 = new Tempera(tempera._marca, tempera._color,(sbyte)(tempera._cantidad + cantidad));
            return tempera3;
        }

        public static Tempera operator +(Tempera tempera, Tempera tempera2)
        {
            Tempera tempera3 = new Tempera(tempera._marca, tempera._color, tempera._cantidad);

            if (tempera == tempera2)
            {
                tempera3 += tempera2;
            }
            return tempera3;
        }

        public static Tempera operator -(Tempera tempera, sbyte cantidad)
        {
            Tempera tempera3 = new Tempera(tempera._marca, tempera._color, (sbyte)(tempera._cantidad - cantidad));
            return tempera3;
        }

        public static Tempera operator -(Tempera tempera, Tempera tempera2)
        {
            Tempera tempera3 = new Tempera(tempera._marca, tempera._color, tempera._cantidad);

            if (tempera == tempera2)
            {
                if (tempera3._cantidad <= 0)
                {
                    tempera3 = null;
                }
                else
                {
                    tempera3 -= tempera2;
                }
            }
            return tempera3;
        }


    }
}
