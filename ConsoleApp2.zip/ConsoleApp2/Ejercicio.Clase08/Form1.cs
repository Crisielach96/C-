﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using Entidades;

namespace Ejercicio.Clase08
{
    public partial class Form1 : Form
    {
        Paleta _miPaleta;

        public Form1()
        {
            InitializeComponent();
            this._miPaleta = new Paleta(5);
            this.groupBox1.Text = "paleta De Colores";
            this.textBox1.Multiline = true;
            this.button1.Text = "+";
            this.button2.Text = "-";
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.groupBox1.Visible = true;
            this.menuStrip1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmTempera frmtempera = new FrmTempera();
            frmtempera.Show();

            this._miPaleta += frmtempera.MiTempera;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
