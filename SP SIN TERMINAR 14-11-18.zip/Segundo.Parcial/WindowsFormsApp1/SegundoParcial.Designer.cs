﻿namespace SP
{
    partial class SegundoParcial
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPunto6 = new System.Windows.Forms.Button();
            this.btnPunto7 = new System.Windows.Forms.Button();
            this.btnPunto5 = new System.Windows.Forms.Button();
            this.btnPunto4 = new System.Windows.Forms.Button();
            this.btnPunto3 = new System.Windows.Forms.Button();
            this.btnPunto2 = new System.Windows.Forms.Button();
            this.btnPunto1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPunto6
            // 
            this.btnPunto6.Location = new System.Drawing.Point(12, 157);
            this.btnPunto6.Name = "btnPunto6";
            this.btnPunto6.Size = new System.Drawing.Size(260, 23);
            this.btnPunto6.TabIndex = 23;
            this.btnPunto6.Text = "PUNTO 6";
            this.btnPunto6.UseVisualStyleBackColor = true;
            this.btnPunto6.Click += new System.EventHandler(this.btnPunto6_Click);
            // 
            // btnPunto7
            // 
            this.btnPunto7.Location = new System.Drawing.Point(12, 186);
            this.btnPunto7.Name = "btnPunto7";
            this.btnPunto7.Size = new System.Drawing.Size(260, 23);
            this.btnPunto7.TabIndex = 21;
            this.btnPunto7.Text = "PUNTO 7";
            this.btnPunto7.UseVisualStyleBackColor = true;
            this.btnPunto7.Click += new System.EventHandler(this.btnPunto7_Click);
            // 
            // btnPunto5
            // 
            this.btnPunto5.Location = new System.Drawing.Point(12, 128);
            this.btnPunto5.Name = "btnPunto5";
            this.btnPunto5.Size = new System.Drawing.Size(260, 23);
            this.btnPunto5.TabIndex = 20;
            this.btnPunto5.Text = "PUNTO 5";
            this.btnPunto5.UseVisualStyleBackColor = true;
            this.btnPunto5.Click += new System.EventHandler(this.btnPunto5_Click);
            // 
            // btnPunto4
            // 
            this.btnPunto4.Location = new System.Drawing.Point(12, 99);
            this.btnPunto4.Name = "btnPunto4";
            this.btnPunto4.Size = new System.Drawing.Size(260, 23);
            this.btnPunto4.TabIndex = 19;
            this.btnPunto4.Text = "PUNTO 4";
            this.btnPunto4.UseVisualStyleBackColor = true;
            this.btnPunto4.Click += new System.EventHandler(this.btnPunto4_Click);
            // 
            // btnPunto3
            // 
            this.btnPunto3.Location = new System.Drawing.Point(12, 70);
            this.btnPunto3.Name = "btnPunto3";
            this.btnPunto3.Size = new System.Drawing.Size(260, 23);
            this.btnPunto3.TabIndex = 18;
            this.btnPunto3.Text = "PUNTO 3";
            this.btnPunto3.UseVisualStyleBackColor = true;
            this.btnPunto3.Click += new System.EventHandler(this.btnPunto3_Click);
            // 
            // btnPunto2
            // 
            this.btnPunto2.Location = new System.Drawing.Point(12, 41);
            this.btnPunto2.Name = "btnPunto2";
            this.btnPunto2.Size = new System.Drawing.Size(260, 23);
            this.btnPunto2.TabIndex = 17;
            this.btnPunto2.Text = "PUNTO 2";
            this.btnPunto2.UseVisualStyleBackColor = true;
            this.btnPunto2.Click += new System.EventHandler(this.btnPunto2_Click);
            // 
            // btnPunto1
            // 
            this.btnPunto1.Location = new System.Drawing.Point(12, 12);
            this.btnPunto1.Name = "btnPunto1";
            this.btnPunto1.Size = new System.Drawing.Size(260, 23);
            this.btnPunto1.TabIndex = 16;
            this.btnPunto1.Text = "PUNTO 1";
            this.btnPunto1.UseVisualStyleBackColor = true;
            this.btnPunto1.Click += new System.EventHandler(this.btnPunto1_Click);
            // 
            // SegundoParcial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 226);
            this.Controls.Add(this.btnPunto6);
            this.Controls.Add(this.btnPunto7);
            this.Controls.Add(this.btnPunto5);
            this.Controls.Add(this.btnPunto4);
            this.Controls.Add(this.btnPunto3);
            this.Controls.Add(this.btnPunto2);
            this.Controls.Add(this.btnPunto1);
            this.Name = "SegundoParcial";
            this.Text = "Segundo Parcial";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPunto6;
        private System.Windows.Forms.Button btnPunto7;
        private System.Windows.Forms.Button btnPunto5;
        private System.Windows.Forms.Button btnPunto4;
        private System.Windows.Forms.Button btnPunto3;
        private System.Windows.Forms.Button btnPunto2;
        private System.Windows.Forms.Button btnPunto1;
    }
}

