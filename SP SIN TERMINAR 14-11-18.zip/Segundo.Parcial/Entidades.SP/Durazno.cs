﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.SP
{
    public class Durazno : Fruta
    {
        protected int cantPelusa;

        public string Nombre { get { return "Durazno"; } }

        public Durazno(string color, double peso, int pelusa) : base(color, peso)
        {
            this.cantPelusa = pelusa;
        }

        public override bool TieneCarozo => true;

        public override string ToString()
        {
            return base.FrutaToString() + " " + this.cantPelusa;
        }
    }
}
