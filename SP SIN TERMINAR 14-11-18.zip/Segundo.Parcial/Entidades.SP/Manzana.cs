﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades.SP
{
    public class Manzana:Fruta,ISerializar
    {
        protected string ProvinciaDeOrigen;

        public string Nombre { get { return "Manzana"; } }

        public Manzana(string color, double peso, string provincia):base(color,peso)
        {
            this.ProvinciaDeOrigen = provincia;
        }

        public override bool TieneCarozo => true;

        public override string ToString()
        {
            return base.FrutaToString() + " " + this.ProvinciaDeOrigen;
        }

        public bool Xml(string s)
        {
            bool returnValue = true;

            try
            {
                XmlTextWriter xmlT = new XmlTextWriter(this.RutaArchivo + s, Encoding.UTF8);

                XmlSerializer xmlS = new XmlSerializer(typeof(Manzana));

                xmlS.Serialize(xmlT, this);

                xmlT.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }

        public string RutaArchivo { get; set; }

        public bool Xml(string s,out Fruta f)
        {
            bool returnValue = true;

            try
            {
                XmlTextReader xmlR = new XmlTextReader(this.RutaArchivo+s);
                XmlSerializer xmlS = new XmlSerializer(typeof(Manzana));

                Manzana m = (Manzana)xmlS.Deserialize(xmlR);

                this._color = m._color;
                this._peso = m._peso;
                this.ProvinciaDeOrigen = m.ProvinciaDeOrigen;
                
                xmlR.Close();
                
            }
            catch (Exception)
            {
                returnValue = false;
            }

            f = this;
            return returnValue;
        }
    }

    
}
