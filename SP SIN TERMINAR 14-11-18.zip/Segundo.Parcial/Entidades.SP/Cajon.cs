﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades.SP
{
    [Serializable]
    public class Cajon<T> : ISerializar
    {
        protected int _capacidad;
        protected List<T> _elementos;
        protected double _precioUnitario;

        public List<T> Elementos
        {
            get { return this._elementos; }
        }

        public double PrecioTotal
        {
            get
            {
                return (this._precioUnitario * this._elementos.Count);
            }
        }

        public Cajon()
        {
            this._elementos = new List<T>(this._capacidad);
        }

        public Cajon(int capacidad)
            : this()
        {
            this._capacidad = capacidad;
        }

        public Cajon(int capacidad, double precio)
            : this(capacidad)
        {
            this._precioUnitario = precio;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Capacidad del cajon: " + this._capacidad.ToString());
            sb.AppendLine("Cantidad de frutas: " + this._elementos.Count.ToString());
            sb.AppendLine("Precio total del cajon: " + this.PrecioTotal.ToString());

            foreach (T f in this._elementos)
            {
                sb.AppendLine(f.ToString());
            }

            return sb.ToString();
        }

        public static Cajon<T> operator +(Cajon<T> c, T f)
        {
            if (c._elementos.Count + 1 <= c._capacidad)
            {
                c._elementos.Add(f);
            }
            else
            {
                throw new CajonLlenoException("No hay mas espacio para guardar frutas en el cajon.");
            }

            return c;
        }
        
        public string RutaArchivo
        {
            get;
            set;
        }

        public bool Xml(string s)
        {
            bool returnValue = true;

            try
            {
                XmlTextWriter xmlT = new XmlTextWriter(this.RutaArchivo+s, Encoding.UTF8);

                XmlSerializer xmlS = new XmlSerializer(typeof(Cajon<T>));

                xmlS.Serialize(xmlT, this);

                xmlT.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                returnValue = false;
            }
            
            return returnValue;

        }
        
    }
}
