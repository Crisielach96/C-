﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_cartuchera
{
    public abstract class Utiles
    {
        protected double _precio;
        protected string _marca;

        public abstract double _Precio { get; set; }
        public abstract string _Marca { get; set; }

        public virtual string UtilesToString()
        { return this._Marca + " - " + this._Precio; }
    }
}
