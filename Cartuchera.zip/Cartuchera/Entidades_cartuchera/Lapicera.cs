﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_cartuchera
{
    public class Lapicera : Utiles
    {
        protected string _color;
        protected string _trazo;

        public override double _Precio { get => base._precio; set => base._precio=value; }
        public override string _Marca { get => base._marca; set => base._marca=value; }

        public string Color { get => this._color; set => this._color = value; }
        public string Trazo { get => this._trazo; set => this._trazo = value; }

        public override string ToString()
        { return base.UtilesToString() + " - " + this._color + " - " + this._trazo; }
    }
}
