﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_cartuchera
{
    public class Goma : Utiles
    {
        protected bool _soloLapiz;

        public override double _Precio { get => base._precio; set => base._precio = value; }
        public override string _Marca { get => base._marca; set => base._marca = value; }


        public override string ToString()
        {
            return base.UtilesToString() + " - " + this._soloLapiz;
        }
    }
}
