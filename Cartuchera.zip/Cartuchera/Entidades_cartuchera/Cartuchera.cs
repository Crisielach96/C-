﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_cartuchera
{
    public class Cartuchera<T>
    {
        protected string _marca;
        protected byte _capacidad;
        protected List<T> _elementos;

        private Cartuchera()
        {
            this._elementos = new List<T>();
        }
        public Cartuchera(byte capacidad) : this()
        {
            this._capacidad = capacidad;
            this._marca = "";
        }

        public static implicit operator Cartuchera<T>(byte capacidad)
        {
            return new Cartuchera<T>(capacidad);
        }

        public void Add(T elemento)
        {
                if (this._capacidad > this._elementos.Count )
                {
                    this._elementos.Add(elemento);
                }
        }

        public bool Remove(T elemento)
        {
            bool retorno = false;

            foreach (T item in this._elementos)
            {
                if (item.Equals(elemento))
                {
                    this._elementos.Remove(elemento);
                    retorno = true;
                }
            }

            return retorno;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (T item in this._elementos)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString();
        }
    }
}
