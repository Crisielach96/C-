﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades_cartuchera;

namespace Utiles_main
{
    class Program
    {
        static void Main(string[] args)
        {
            Cartuchera<Utiles> cartuchera = 10;
            Lapicera lapicera0 = new Lapicera();
            Lapicera lapicera1 = new Lapicera();
            Lapicera lapicera2 = new Lapicera();
            Goma goma0 = new Goma();
            Goma goma1 = new Goma();
            Goma goma2 = new Goma();

            lapicera0._Marca = "Bic";
            lapicera0._Precio = 9.25;
            lapicera0.Color = "Azul";
            lapicera0.Trazo = "Grueso";

            lapicera1._Marca = "Bic";
            lapicera1._Precio = 9.25;
            lapicera1.Color = "Rojo";
            lapicera1.Trazo = "Fino";

            lapicera2._Marca = "Bic";
            lapicera2._Precio = 9.25;
            lapicera2.Color = "Verde";
            lapicera2.Trazo = "Grueso";

            goma0._Marca = "Maped";
            goma0._Precio = 3;

            goma1._Marca = "asd";
            goma1._Precio = 3;

            goma2._Marca = "ulp";
            goma2._Precio = 3;

            cartuchera.Add(lapicera0);
            cartuchera.Add(lapicera1);
            cartuchera.Add(lapicera2);
            cartuchera.Add(goma0);
            cartuchera.Add(goma1);
            cartuchera.Add(goma2);

            Console.WriteLine(cartuchera.ToString());

            Console.ReadKey();
        }
    }
}
