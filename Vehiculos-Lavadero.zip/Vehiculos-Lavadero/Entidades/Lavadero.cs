﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    class Lavadero
    {
        private List<Vehiculos> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        public Lavadero(string razonSocial) : this()
        {
            this._razonSocial = razonSocial;
        }

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculos>();
        }

        static Lavadero()
        {
            Random rnd = new Random();
            _precioAuto = rnd.Next(150, 566);
            _precioCamion = rnd.Next(150, 566);
            _precioMoto = rnd.Next(150, 566);
        }

        public string LavaderoToString
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("Razon social: " + _razonSocial);
                sb.AppendLine("Precio Auto: " + _precioAuto);
                sb.AppendLine("Precio Moto: " + _precioMoto);
                sb.AppendLine("Precio Camion: " + _precioCamion);

                foreach (Vehiculos item in this._vehiculos)
                {
                    sb.AppendLine(item.ToString());
                }

                return sb.ToString();
            }
        }

        public List<Vehiculos> Vehiculos
        {
            get
            {
                return this._vehiculos;
            }
        }



        public double MostraTotalFacturado()
        {
            double fact = 0;

            foreach (Vehiculos item in this._vehiculos)
            {
                if (item is Auto)
                    fact += _precioAuto;

                if (item is Camion)
                    fact += _precioCamion;

                if (item is Moto)
                    fact += _precioMoto;
            }
            return fact;
        }

        public double MostarTotalFacturado(EVehiculo en)
        {
            double fact = 0;

            foreach (Vehiculos item in this._vehiculos)
            {
                switch (en)
                {
                    case EVehiculo.Auto:
                        if (item is Auto)
                            fact += _precioAuto;
                        break;
                    case EVehiculo.Camión:
                        if (item is Camion)
                            fact += _precioCamion;
                        break;
                    case EVehiculo.Moto:
                        if (item is Moto)
                            fact += _precioMoto;
                        break;

                    default:
                        break;
                }
            }
            return fact;
        }



    }
}
