﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Camion : Vehiculos
    {
        protected float _tara;


        public Camion(string patente, byte cantR, EMarca marca, float tara) : base(patente, cantR, marca)
        {
            this._tara = tara;
        }

        public Camion(Vehiculos v, float tara) : this(v.Patente, 6, v.Marca, tara) { }

        protected override string _mostrar()
        {
            return base._mostrar() + "Tara: " + this._tara.ToString();
        }

        public override string ToString()
        {
            return this._mostrar();
        }
    }
}
