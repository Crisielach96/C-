﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Auto : Vehiculos
    {
        protected int _cantidadAsientos;

        public Auto(string patente,byte cantR, int CantAsientos, EMarca marca) : base(patente,cantR,marca)
        {
            this._cantidadAsientos = CantAsientos;
        }

        public Auto(string patente, int CantAsientos, EMarca marca) : this(patente, 4, CantAsientos, marca) { }

        protected override string _mostrar()
        {
            return base._mostrar() + "Cantidad de asientos: " + this._cantidadAsientos.ToString();
        }

        public override string ToString()
        {
            return this._mostrar();
        }
    }
}
