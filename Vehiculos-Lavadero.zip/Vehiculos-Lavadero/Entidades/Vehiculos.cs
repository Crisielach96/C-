﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Vehiculos
    {
        private string _patente;
        private Byte _cantRuedas;
        private EMarca _marca;

        public string Patente
        {
            get
            {
                return _patente;
            }
        }

        public Byte CantRuedas
        {
            get
            {
                return _cantRuedas;
            }
            set
            {
                _cantRuedas = value;
            }
        }

        public EMarca Marca
        {
            get
            {
                return _marca;
            }
        }

        protected virtual string _mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Marca:" + this.Marca);
            sb.AppendLine("Patente: " + this.Patente);
            sb.AppendLine("Cantidad de ruedas: " + this.CantRuedas);

            return sb.ToString();
        }

        public Vehiculos(string patente, Byte CantRuedas, EMarca marca)
        {
            this._patente = patente;
            this._marca = marca;
            this._cantRuedas = CantRuedas;
        }

        public override string ToString()
        {
            return this._mostrar();
        }

        public static bool operator ==(Vehiculos v1, Vehiculos v2)
        {
            bool retorno = false;

            if (v1._marca == v2._marca && v1._patente == v2._patente)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Vehiculos v1, Vehiculos v2)
        {
            return !(v1 == v2);
        }
    }   
}
