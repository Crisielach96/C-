﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Moto : Vehiculos
    {
        protected float _cilindrada;

        public Moto(string patente, float cilindrada, byte cantRuedas, EMarca marca) : base(patente, cantRuedas, marca)
        {
            this._cilindrada = cilindrada;
        }

        protected override string _mostrar()
        {
            return base._mostrar() + "Cilindrada: " + this._cilindrada.ToString();
        }

        public override string ToString()
        {
            return this._mostrar();
        }

    }
}
