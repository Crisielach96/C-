﻿public enum EVehiculo
{
    Auto,
    Camión,
    Moto
}