﻿public enum EtipoTinta
{
    comun,
    china,
    brillitos
}