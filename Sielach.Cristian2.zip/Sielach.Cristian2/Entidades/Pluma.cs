﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Pluma
    {
        private string _marca;
        private Tinta _tinta;
        private int _cantidad;

        public Pluma()
        {
            this._marca = "";
            this._tinta = null;
            this._cantidad = 0;
        }
        public Pluma(string marca)
            : this()
        {
            this._marca = marca;
        }
        public Pluma(string marca, int cantidad)
            : this(marca)
        {
            this._marca = marca;
            this._cantidad = cantidad;
        }
        public Pluma(string marca, Tinta tinta, int cantidad)
            : this(marca, cantidad)
        {
            this._marca = marca;
            this._cantidad = cantidad;
            this._tinta = tinta;
        }
        private string Mostrar()
        {
            return this._marca + " - " + Tinta.Mostrar(this._tinta) + " - " + this._cantidad;
        }
        public static implicit operator string(Pluma a)
        {
            return a.Mostrar();
        }
        public static bool operator ==(Pluma p, Tinta t)
        {
            return p._tinta == t;
        }
        public static bool operator !=(Pluma p, Tinta t)
        {
            return !(p == t);
        }
        public static Pluma operator +(Pluma p, Tinta t)
        {
            if (p == t && p._cantidad < 100)
            {
                p._cantidad++;
            }
            return p;
        }
        public static Pluma operator -(Pluma p, Tinta t)
        {
            if (p == t && p._cantidad > 0)
            {
                p._cantidad--;
            }
            return p;
        }
    }
}
