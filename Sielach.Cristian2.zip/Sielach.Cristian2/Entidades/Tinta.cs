﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Tinta
    {
        private ConsoleColor color;
        private EtipoTinta tipoTinta;

        public Tinta()
        {
            this.color = ConsoleColor.Black;
            this.tipoTinta = EtipoTinta.comun;
        }
       public Tinta(ConsoleColor colorParam) : this()
        {
            this.color = colorParam;
        }
       public Tinta(ConsoleColor colorParam,EtipoTinta tipoTintaP) : this(colorParam)
        {
            this.tipoTinta = tipoTintaP;
        }

       private string Mostrar()
       {
           return this.color + " - " + this.tipoTinta;
       }
       public static string Mostrar(Tinta tinta)
       {
           return tinta.Mostrar();
       }

        public static bool operator == (Tinta t1 , Tinta t2)
        {
           return t1.color == t2.color && 
                  t1.tipoTinta == t2.tipoTinta; 
        }
        public static bool operator != (Tinta t1 , Tinta t2)
        {
           return !(t1 == t2);
        }

    }
}
