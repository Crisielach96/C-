﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace EjerClase05
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tinta = new Tinta();
            Tinta tinta1 = new Tinta(ConsoleColor.Green);
            Tinta tinta2 = new Tinta(ConsoleColor.Blue,EtipoTinta.china);

            Pluma pluma = new Pluma("Bic",tinta1,5);

            Console.WriteLine(Tinta.Mostrar(tinta));
            Console.WriteLine(Tinta.Mostrar(tinta1));
            Console.WriteLine(Tinta.Mostrar(tinta2));

            Console.WriteLine(pluma);

            if (tinta == tinta1)
            {
                Console.WriteLine("Son Iguales");
            }
            else
            {
                Console.WriteLine("No son iguales");
            }

            Console.ReadKey();
        }
    }
}
