﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tempera
{
    class Paleta
    {
        private Tempera[] _Colores;
        private int _cantMaxColores;

        private Paleta() : this(5) { }

        private Paleta(int cant)
        {
            this._cantMaxColores = cant;
            this._Colores = new Tempera[this._cantMaxColores];
        }

        public static implicit operator Paleta(int p)
        {
            Paleta paleta = new Paleta(p);
            return paleta;
        }
        private string Mostrar()
        {
            string colores = "";
            colores += "La cantidad de colores es: " + this._cantMaxColores + "\n";

            for (int i = 0; i < this._cantMaxColores; i++)
            {
                if (this._Colores.GetValue(i) != null)
                {
                    colores += Tempera.Mostrar(this._Colores[i]) + "\n";
                }
            }
            return colores;
        }
        public static explicit operator string(Paleta p)
        {
            return p.Mostrar();
        }
        public static bool operator ==(Paleta p, Tempera t)
        {
            bool resp = false;
            int index = 0;

            foreach (Tempera i in p._Colores)
            {
                if (i == p._Colores[index])
                {
                    resp = true;
                    break;
                }
                index++;
            }
            return resp;
        }
        public static bool operator !=(Paleta p, Tempera t)
        {
            return !(p == t);
        }
        private int obtenerIndice()
        {
            int resp = -1;
            int index = 0;

            foreach (Tempera i in this._Colores)
            {
                if (((object)i) == null)
                {
                    resp = index;
                    break;
                }
                index++;
            }
            return resp;
        }

        private int obtenerIndice(Tempera t)
        {
            int resp = -1;
            int index = 0;

            foreach (Tempera i in this._Colores)
            {
                if (t == this._Colores[index])
                {
                    resp = index;
                    break;
                }
                index++;
            }
            return resp;
        }
        public static Paleta operator +(Paleta p, Tempera t)
        {
            if (p == t)
            {
                
            }

            return 0;
        }
        //public static Paleta operator -(Paleta p, Tempera t)
    }
}
