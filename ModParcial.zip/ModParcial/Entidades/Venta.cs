﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ventas
{
    using Articulos;

    public class Venta
    {
        private Articulo _articuloVendido;
        private int _cantidad;

        public float RetornarGanancias()
        {
            return this._cantidad * this._articuloVendido.PrecioVenta;
        }

        public Venta(Articulo articuloVendido, int cantidad)
        {
            this._articuloVendido = articuloVendido;
            this._cantidad = cantidad;
        }
    }
}
