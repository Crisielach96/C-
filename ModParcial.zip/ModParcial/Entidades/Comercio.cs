﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Articulos;
using Ventas;

namespace Comercios
{
    public class Comercio
    {
        private string _dueño;
        private List<Articulo> _misArticulos;
        private List<Venta> _misVentas;

        public Comercio(string dueño)
        {
            this._dueño = dueño;
            this._misArticulos = new List<Articulo>();
            this._misVentas = new List<Venta>();
        }

        public void ComprarArticulo(Articulo articuloComprado)
        {
            bool flag = false;

            foreach (Articulo i in this._misArticulos)
            {
                if (articuloComprado == i)
                {
                    flag = true;
                    i.Stock = i + articuloComprado;
                    break;
                }
            }
            if (flag == false)
            {
                this._misArticulos.Add(articuloComprado);
            }
        }

        public void VenderArticulo(Articulo articuloSolicitado, int cantidad)
        {
            bool flag = false;

            foreach (Articulo i in this._misArticulos)
            {
                if (articuloSolicitado == i)
                {
                    if (i.HayStock(cantidad))
                    { 
                        flag = true;
                        i.Stock = i - cantidad;
                        Venta venta = new Venta(articuloSolicitado, cantidad);
                        this._misVentas.Add(venta);
                        break;
                    }     
                }
            }
            if (flag == false)
            {
                Console.WriteLine("El producto no existe");
            }
        }

        public static void MostrarArticulos(Comercio comercioAMostrar)
        {
            foreach (Articulo i in comercioAMostrar._misArticulos)
            {
                Console.WriteLine(i.NombreYCodigo);
            }
        }

        public static void MostrarGanancias(Comercio comercioParaResumen)
        {
            float gananciaTotal=0;

            foreach (Venta i in comercioParaResumen._misVentas)
            {
                gananciaTotal += i.RetornarGanancias();
            }

            Console.WriteLine("La ganancia total es: {0}", gananciaTotal);

        }

    }
}
