﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Articulos
{
    public class Articulo
    {
        private int _codigo;
        private string _nombre;
        private float _precioCosto;
        private float _precioVenta;
        private int _stock;

        public virtual string NombreYCodigo 
        {
            get
            {
                return this._nombre + " -- " + this._codigo;
            }
        }

        public virtual float PrecioCosto 
        {
            set
            {
                this._precioVenta = value * 1.30f;
                this._precioCosto = value;
            }
        }

        public virtual float PrecioVenta 
        {
            get
            {
                return this._precioVenta;
            }
        }

        public virtual int Stock 
        {
            set
            {
                this._stock = value;
            }
        }

        public Articulo(int codigo, string nombre, float precioCosto, int cantidad)
        {
            this._codigo = codigo;
            this._nombre = nombre;
            this.PrecioCosto = precioCosto;
            this._stock = cantidad;
        }

        public bool HayStock(int cantidad)
        {
            bool resp=false;

            if (cantidad < this._stock)
            {
                resp = true;
            }
            else
            {
                Console.WriteLine("No hay mas stock");
            }

            return resp;
        }

        public static bool operator ==(Articulo articuloUno, Articulo articuloDos)
        {
            bool resp=false;

            if (articuloUno._codigo == articuloDos._codigo
                && articuloUno._nombre == articuloDos._nombre)
            {
                resp = true;
            }

            return resp;
        }

        public static bool operator !=(Articulo articuloUno, Articulo articuloDos)
        {
            return !(articuloUno == articuloDos);
        }

        public static int operator +(Articulo articuloUno, Articulo articuloDos)
        {
            return articuloUno._stock + articuloDos._stock;
        }

        public static int operator -(Articulo articuloUno, int cantidad)
        {
            return articuloUno._stock - cantidad;
        }
    }
}
