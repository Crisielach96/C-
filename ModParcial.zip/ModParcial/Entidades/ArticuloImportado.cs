﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Articulos
{
    public class ArticuloImportado : Articulo
    {
        private string _paisDeOrigen;
        private int _impuesto;

        public ArticuloImportado(int codigo, string nombre, float precioCosto, int cantidad, string pais, int impuesto) : base(codigo, nombre, precioCosto, cantidad)
        {
            this._paisDeOrigen = pais;
            this._impuesto = impuesto;
        }


    }
}
