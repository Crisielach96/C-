﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PaletaColeccion
    {
        List<Tempera> _colores;
        private int _cantMaximaElementos;

        #region Constructores
        private PaletaColeccion() : this(5) { }

        public PaletaColeccion(int cantMaximaElementos)
        {
            this._cantMaximaElementos = cantMaximaElementos;
            this._colores = new List<Tempera>(cantMaximaElementos);
        }
        #endregion

        private string Mostrar()
        {

            string retorno = "";

            Console.WriteLine(this._cantMaximaElementos);

            foreach (Tempera item in this._colores)
            {

                retorno += item;
            }
            return retorno;
        }

        public static explicit operator string(PaletaColeccion paleta)
        {
            return paleta.Mostrar();
        }

        public static implicit operator PaletaColeccion(int num)
        {
            return new PaletaColeccion(num);
        }

        public static bool operator ==(PaletaColeccion p, Tempera t)
        {
            bool retorno = false;

            foreach (Tempera item in p._colores)
            {
                    if (t == item)
                    {
                        retorno = true;
                        break;
                    }
            }
            return retorno;
        }

        public static bool operator !=(PaletaColeccion p, Tempera t)
        {
            return !(p == t);
        }

        private int ObtenerIndice()
        {
            int retorno = -1;
            int contador = 0;
            foreach (Tempera item in this._colores)
            {
                
               retorno = contador;
               break;
               
            }
            return retorno;
        }

        private int ObtenerIndice(Tempera tempera)
        {
            int retorno = -1;
            int contador = 0;

            foreach (Tempera item in this._colores)
            {
                
                    if (tempera == item)
                    {
                        retorno = contador;
                        break;
                    }

                
                contador++;
            }
            return retorno;
        }

        public static PaletaColeccion operator +(PaletaColeccion paleta, Tempera tempera)
        {
            PaletaColeccion retrono = new PaletaColeccion();

            foreach(Tempera item in paleta._colores)
            {
                retrono._colores.Add(item);
            }
            foreach(Tempera item in paleta._colores)
            {
                retrono._colores.Add(item);
            }
            return retrono;
        }

        public static PaletaColeccion operator -(PaletaColeccion paleta, Tempera tempera)
        {
            int indice = -1;
            sbyte aux1, aux2;

            if (paleta == tempera)
            {
                indice = paleta.ObtenerIndice(tempera);
                aux1 = (sbyte)paleta._colores[indice];
                aux2 = (sbyte)tempera;

                if (aux1 - aux2 <= 0)
                {
                    paleta._colores[indice] = null;
                }
                else
                {
                    paleta._colores[indice] += (sbyte)(aux2 * (-1));
                }
            }

            return paleta;
        }
    }
}