using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
  public class Paleta
  {
    private Tempera[] _colores;
    private int _cantMaximaElementos;

    #region Constructores
    private Paleta() : this(5) { }

    public Paleta(int cantMaximaElementos)
    {
      this._cantMaximaElementos = cantMaximaElementos;
      this._colores = new Tempera[this._cantMaximaElementos];
    }
    #endregion

    private string Mostrar()
    {

      string retorno = "";

      Console.WriteLine(this._cantMaximaElementos);

      foreach (Tempera item in this._colores)
      {

        retorno += item;
      }
      return retorno;
    }

    public static explicit operator string(Paleta paleta)
    {
      return paleta.Mostrar();
    }

    public static implicit operator Paleta(int num)
    {
      return new Paleta(num);
    }

    public static bool operator ==(Paleta p, Tempera t)
    {
      bool retorno = false;
      int contador = 0;

      foreach (Tempera item in p._colores)
      {
        if (p._colores.GetValue(contador) != null)
        {
          if (t == item)
          {
            retorno = true;
            break;
          }
        }
        contador++;
      }
      return retorno;
    }

    public static bool operator !=(Paleta p, Tempera t)
    {
      return !(p == t);
    }

    private int ObtenerIndice()
    {
      int retorno = -1;
      int contador = 0;
      foreach (Tempera item in this._colores)
      {
        if (this._colores.GetValue(contador) == null)
        {
          retorno = contador;
          break;
        }
        contador++;
      }
      return retorno;
    }

    private int ObtenerIndice(Tempera tempera)
    {
      int retorno = -1;
      int contador = 0;

      foreach (Tempera item in this._colores)
      {
        if (this._colores.GetValue(contador) != null)
        {
          if (tempera == item)
          {
            retorno = contador;
            break;
          }

        }
        contador++;
      }
      return retorno;
    }

    public static Paleta operator +(Paleta paleta, Tempera tempera)
    {
      //int indice = -1;

      //if (paleta == tempera)
      //{
      //    indice = paleta.ObtenerIndice(tempera);
      //    paleta._colores[indice] += tempera;
      //}
      //else
      //{
      //    indice = paleta.ObtenerIndice();
      //    if(indice > -1)
      //    paleta._colores[indice] = tempera;
      //}
      //return paleta;

      int index = 0;
      int index2 = 0;

      index = paleta.ObtenerIndice();
      index2 = paleta.ObtenerIndice(tempera);


      if (paleta == tempera)
      {
        if (index2 >= 0)
        {
          paleta._colores[index2] += tempera;
        }
      }
      else
      {
        if (index > -1)
        {
          paleta._colores[index] = tempera;
        }
      }
      return paleta;
    }

    public static Paleta operator -(Paleta paleta, Tempera tempera)
    {
      int indice = -1;
      sbyte aux1, aux2;

      if (paleta == tempera)
      {
        indice = paleta.ObtenerIndice(tempera);
        aux1 = (sbyte)paleta._colores[indice];
        aux2 = (sbyte)tempera;

        if (aux1 - aux2 <= 0)
        {
          paleta._colores[indice] = null;
        }
        else
        {
          paleta._colores[indice] += (sbyte)(aux2 * (-1));
        }
      }

      return paleta;
    }
  }
}
