﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades30_5;
namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string salir = "s";

            while (salir == "s")
            {
                Console.Write("Ingrese una opcion mayor a 0 :");
                int opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        {
                            foreach (Persona per in Persona.TraerTodos())
                            {
                                Console.WriteLine(per.ToString());
                            }

                            break;
                        }

                    case 2:
                        {
                            Persona p1 = new Persona("Cristian", "Siealch", 21);

                            if (p1.Agregar())
                            {
                                Console.WriteLine("\nSe agregó correctamente\n\n");
                            }
                            else
                            {
                                Console.WriteLine("\nNo se agregó\n");
                            }

                            foreach (Persona per in Persona.TraerTodos())
                            {
                                Console.WriteLine(per.ToString());
                            }
                            break;
                        }

                    case 3:
                        {
                            int id;

                            Console.Write("Ingrese un ID mayor a 0 :");
                            id = int.Parse(Console.ReadLine());

                            foreach (Persona per in Persona.TraerTodos())
                            {
                                if (per.Id == id)
                                {
                                    Persona.Borrar(per);
                                }
                            }

                            foreach (Persona per in Persona.TraerTodos())
                            {
                                Console.WriteLine(per.ToString());
                            }

                            break;
                        }

                    case 4:
                        {
                            salir = "n";

                            break;
                        }
                }
            }
            
            Console.ReadKey();
        }
    }
}
