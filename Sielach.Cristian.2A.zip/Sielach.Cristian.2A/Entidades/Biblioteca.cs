﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Biblioteca
    {
        private int _capacidad;
        private List<Libro> _libros;

        public double PrecioDeManuales
        {
            get
            {
                return this.ObtenerPrecio(ELibro.Manual);
            }
        }
        public double PrecioDeNovelas
        {
            get
            {
                return this.ObtenerPrecio(ELibro.Novela);
            }
        }
        public double PrecioTotal
        {
            get
            {
                return this.ObtenerPrecio(ELibro.Ambos);
            }
        }

        private Biblioteca()
        {
            this._libros = new List<Libro>();
        }

        private Biblioteca(int capacidad):this()
        {
            this._capacidad = capacidad;
        }

        public static implicit operator Biblioteca(int capacidad)
        {
            return new Biblioteca(capacidad);
        }

        public static string Mostrar(Biblioteca b)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad de la Biblioteca: "+b._capacidad);
            sb.AppendLine("Total por Manuales: "+b.PrecioDeManuales);
            sb.AppendLine("Total por Novelas: "+b.PrecioDeNovelas);
            sb.AppendLine("Total: " + b.PrecioTotal);
            
            sb.AppendLine("---------------------------------------------------");
            sb.AppendLine("Listado de Libros");
            sb.AppendLine("---------------------------------------------------");
            foreach (Libro libro in b._libros)
            {
                if (libro is Manual)
                {
                    sb.AppendLine(((Manual)libro).Mostrar());
                }

                if (libro is Novela)
                {
                    sb.AppendLine(((Novela)libro).Mostrar());
                }
            }

            return sb.ToString();
        }
        private double ObtenerPrecio(ELibro tipoLibro)
        {
            double acumuladorMan = 0;
            double acumuladorNov = 0;
            double total = 0;
            foreach(Libro elemento in this._libros)
            {
                if(elemento is Manual)
                {
                    acumuladorMan += ((Manual)elemento);
                }
                if(elemento is Novela)
                {
                    acumuladorNov += ((Novela)elemento);
                }
                switch(tipoLibro)
                {
                    case ELibro.Manual:
                        total = acumuladorMan;
                        break;
                    case ELibro.Novela:
                        total = acumuladorNov;
                        break;
                    case ELibro.Ambos:
                        total = acumuladorMan + acumuladorNov;
                        break;
                    default:
                        break;
                }
            }
            return total;
        }
        public static bool operator !=(Biblioteca b,Libro l)
        {
            return (!(b == l));
        }
        public static Biblioteca operator +(Biblioteca b,Libro l)
        {
            if (b._capacidad <= b._libros.Count)
            {
                Console.WriteLine("No hay mas espacio en la Biblioteca!!");
            }
            else if(b == l)
            {
                Console.WriteLine("El libro ya se encuentra en la Biblioteca!!");
            }
            else
            {
                b._libros.Add(l);
            }                
            return b;
        }
        public static bool operator ==(Biblioteca b,Libro l)
        {
            foreach(Libro elemento in b._libros)
            {
                if (elemento.Equals(l) && (elemento == l))
                    return true;
            }
            return false;
        }
    }
}
