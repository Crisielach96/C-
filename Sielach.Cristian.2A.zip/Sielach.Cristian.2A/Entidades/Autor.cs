﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Autor
    {
        private string nombre;
        private string apellido;

        public Autor(string nombre, string apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }

        public static bool operator ==(Autor a, Autor b)
        {
            bool retorno = false;
            if (a.nombre == b.nombre && a.apellido == b.apellido)
                retorno = true;

            return retorno;
        }

        public static bool operator !=(Autor au1, Autor au2)
        {
            return !(au1 == au2);
        }

        public static implicit operator string(Autor a)
        {
            return "Autor: " + a.nombre + " - " + a.apellido;
        }
    }
}
