﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Libro
    {
        protected Autor _autor;
        protected int _cantidadDePaginas;
        protected static Random _generadorDePaginas;
        protected float _precio;
        protected string _titulo;

        public Libro()
        {
            _generadorDePaginas = new Random();
        }

        public Libro(float precio, string titulo, string nombre, string apellido)
        {
            Autor auxiliar = new Autor(nombre, apellido);
            this._autor = auxiliar;
            this._titulo = titulo;
            this._precio = precio;
        }
        
        public Libro(string titulo, Autor autor, float precio)
        {
            this._titulo = titulo;
            this._autor = autor;
            this._precio = precio;
        }

        public int CantidadDePaginas
        {
            get
            {
                Libro._generadorDePaginas = new Random();
                int random = _generadorDePaginas.Next(10, 580);

                if (_cantidadDePaginas == 0)
                {
                    return _cantidadDePaginas =Libro._generadorDePaginas.Next(10, 580);
                }

                else return _cantidadDePaginas;
            }

        }

        private string Mostrar(Libro l)
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine("Titulo: " + l._titulo);
            cadena.AppendLine(l._autor);
            cadena.AppendLine("Cantidad de paginas: " + l.CantidadDePaginas);
            cadena.AppendLine("Precio: " + l._precio);

            return cadena.ToString();
        }

        public static bool operator ==(Libro a, Libro b)
        {
            bool retorno = false;
            if ((a._titulo == b._titulo) && (a._autor == b._autor))
                retorno = true;
                
            return retorno;
        }

        public static bool operator !=(Libro a, Libro b)
        {
            return !(a == b);
        }

        public static explicit operator string(Libro l)
        {
            return l.Mostrar(l);
    }
}
}
