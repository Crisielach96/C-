using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Sello
    {
        public static string mensaje;
        public static ConsoleColor color;

        public static string imprimir()
        {
            bool ok = TryParse(mensaje, out mensaje);
            string resp = "Error";

            if (ok)
            {
                mensaje = Sello.ArmarFormatoMensaje();
                return mensaje;
            }
            else
            {
                return resp;
            }
        }

        public static void borrar()
        {
            mensaje = "Mensaje borrado";
        }
        public static void ImprimirColor()
        {
            Console.BackgroundColor = Sello.color;
            Console.Write(Sello.mensaje);
            Console.BackgroundColor = ConsoleColor.White;
        }
        private static string ArmarFormatoMensaje()
        {
            int largo;
            string encuadre = "";

            largo = Sello.mensaje.Length;

            for (int i = 0; i < largo + 2; i++)
            {
                encuadre += "*";
            }
            encuadre += "\n";
            encuadre += "*";
            encuadre += Sello.mensaje;
            encuadre += "*\n";

            for (int i = 0; i < largo + 2; i++)
            {
                encuadre += "*";
            }

            return encuadre;
        }

        private static bool TryParse(string entrada, out string devuelve)
        {

            bool resp = false;
            int largo = entrada.Length;

            if (largo != 0)
            {
                devuelve = Sello.mensaje;
                resp = true;
            }
            else
            {
                devuelve = "";
            }

            return resp;

        }

    }
}
