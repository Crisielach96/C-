using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase05
{
  class Tinta
  {
    private ConsoleColor _color;
    private ETipoTinta _tipo;

    public Tinta() { this._color = ConsoleColor.Blue; this._tipo = ETipoTinta.ConBrillitos; }
    public Tinta(ConsoleColor color):this() { this._color = color; }
    public Tinta(ConsoleColor color, ETipoTinta tinta):this(color) {this._tipo = tinta; }


    public static string Mostrar(Tinta t)
    {
      return t.Mostrar();
    }

    private string Mostrar()
    {
      string retorno = "";

      retorno += this._color;
      retorno += " - ";
      retorno += this._tipo;

      return retorno;
    }

    public static bool operator ==(Tinta t1, Tinta t2)
    {
      bool retorno = false;
      if (t1._color == t2._color && t1._tipo == t2._tipo)
      {
        retorno = true;
      }
      return retorno;
    }

    public static bool operator !=(Tinta t1, Tinta t2) => !(t1 == t2);
  }
}
