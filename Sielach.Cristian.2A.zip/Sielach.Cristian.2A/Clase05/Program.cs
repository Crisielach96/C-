using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase05
{
  class Program
  {
    static void Main(string[] args)
    {
      Tinta tinta1 = new Tinta();
      Tinta tinta2 = new Tinta(ConsoleColor.DarkGray, ETipoTinta.Comun);
      Tinta tinta3 = new Tinta(ConsoleColor.DarkGray, ETipoTinta.Comun);
      Console.WriteLine(value: Tinta.Mostrar(tinta1));
      Console.WriteLine(value: Tinta.Mostrar(tinta2));

      if (tinta1 == tinta3)
      { Console.WriteLine("Son iguales"); }
      else { Console.WriteLine("Son diferentes"); }

      if (tinta2 == tinta3)
      { Console.WriteLine("Son iguales"); }
      else { Console.WriteLine("Son diferentes"); }

      Console.ReadKey();
    }
  }
}
