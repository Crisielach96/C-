public enum ETipoTinta
{
  Comun,
  China,
  ConBrillitos
}
