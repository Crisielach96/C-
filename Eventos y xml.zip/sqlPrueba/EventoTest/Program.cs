using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesTV;

namespace EventoTest
{
  class Program
  {

    public static void MiTest()
    {
      Console.WriteLine("Se inseerto a la base de dato");
    }

    public void MiTest2()
    {
      Console.WriteLine("Estoy en el segundo de los delegados");
    }

    public void EventoTV(Televisor tele,TvEventArg eventArg)
    {
      Console.WriteLine(tele.ToString());
      Console.WriteLine(eventArg.Fecha);
    }

    static void Main(string[] args)
    {
      Program p = new Program();
      Televisor televisor = new Televisor(22,"Samsung",18999,21,"EE.UU");

      televisor.MiEvento += new MiDelegado(MiTest);
      televisor.MiEvento += new MiDelegado(p.MiTest2);
      televisor.EventoTV += new MiDelegadoDos(p.EventoTV);
      televisor.Insertar();

      Console.ReadKey();
    }
  }
}
