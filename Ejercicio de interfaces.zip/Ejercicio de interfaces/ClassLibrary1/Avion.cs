﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class Avion : Vehiculo , IAFIP
    {
        protected double _velocidadMaxima;

        public override double Precio { get=>this._precio; set=>this._precio=value; }

        public double PropiedadCalcularImpuesto { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public Avion(double precio, double velMax) : base(precio)
        {
            this._velocidadMaxima = velMax;
        }

        public double CalcularImpuesto()
        {
            return this._precio += this._precio * (0.33);
        }
    }
}
