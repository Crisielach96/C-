﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public abstract class Auto : Vehiculo
    {
        protected string _patente;

        public virtual string Patente { get=>this._patente; set=>this._patente=value; }

        public Auto(double precio, string patente) : base(precio)
        {
            this._patente = patente;
        }

        public void MostarPatente()
        {
            Console.WriteLine(this._patente);
        }
    }
}
