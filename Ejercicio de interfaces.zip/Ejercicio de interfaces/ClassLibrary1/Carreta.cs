﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Carreta : Vehiculo,IAFIP
    {
        public Carreta(double precio) : base(precio) { }

        public override double Precio { get=>this._precio; set=>this._precio=value; }
    }
}
