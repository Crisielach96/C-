﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Deportivo : Auto,IAFIP
    {
        protected int _caballosFuerza;

        public override double Precio { get=>this._precio; set=>this._precio=value; }

        public override string Patente { get=>this._patente; set=>this._patente=value; }

        public double PropiedadCalcularImpuesto { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public Deportivo(double precio, string patente, int hp) : base(precio, patente)
        {
            this._caballosFuerza = hp;
        }

        public double CalcularImpuesto()
        {
            return this._precio += this._precio * (0.28);
        }
    }
}
